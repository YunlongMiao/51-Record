#ifndef _LCD12864_H_
#define _LCD12864_H_

#include <reg51.h>
#define uchar unsigned char
#define uint unsigned int

sbit PSB = P2 ^ 4;
sbit SCLK = P2 ^ 5;
sbit SID = P2 ^ 6;


//д������
extern void write_com(uchar com);
//д������
extern void write_data(uchar dat);
//LCD��ʼ��
extern void initial_12864();

extern void Delayms(uint n);
//LCD��Ļ��ַ��λ
extern void LCD_Setaddress(uchar x, uchar y);

extern void LCD_Putstring( uchar x, uchar y, uchar *pData );
#endif