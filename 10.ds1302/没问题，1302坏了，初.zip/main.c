#include"LCD1602.h"
#include"ds1302.h"

void main()
{
//	initial_12864();
	initial_1602();
	ds1302_initial();
	while(1)
	{	
		read_1302time();
		display_1302();
	}

}