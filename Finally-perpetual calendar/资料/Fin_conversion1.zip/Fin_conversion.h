#ifndef __FIN_CONVERSION_H__
#define __FIN_CONVERSION_H__
#include"Fin_main.h"
extern void Conversion(uchar year,uchar month,uchar day);
#endif