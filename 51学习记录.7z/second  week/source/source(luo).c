#include <reg52.h>

sbit Beep = P1^5; 

#define uint unsigned int 
#define uchar unsigned char


uint arr[50]={95,95,63,63,56,56,63,63,71,71,
							75,75,85,85,95,95,63,63,71,71,
							75,75,85,85,63,63,71,71,75,75,
							85,85,95,95,63,63};




void time(uint xms)
{
	uint x=0,y=0;
	for(x=0;x<xms;x++)
	{
		for(y=10;y<110;y++);
	}
}

void mu(uint i)
{
	while(i--);
}


void main()
{
	uint k=0;
	uint j=0;
	while(1)
	{
		if(j==36)
		{
			j=0;
		}
		for(k=0;k<300;k++)
		{
			Beep=~Beep;
			mu(arr[j]);
		}
		time(800);
		j++;
	}
	
}