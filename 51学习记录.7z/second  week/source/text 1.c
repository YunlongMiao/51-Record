#include<reg51.h>
#define uint unsigned int
#define uchar unsigned char	
sbit Beep=P1^4;

void main()
{
	void Delay10us(uint s);
int delay(unsigned char t);
	//uint  _Ordinal[42]={1,1,5,5,6,6,5,4,4,3,3,2,2,1,5,5,4,4,3,3,2,5,5,4,4,3,3,2,1,1,5,5,6,6,5,4,4,3,3,2,2,1};

	uint _music[7]={191,170,151,144,127,113,101};
	uint  _tab[7]={2,2,2,2,2,2,4};
	uint m,n,x,t,y,z;
	while(1)
	{
//		 x=7;
		//for( t=0; t<1; t++)
		//{
			x=7;
			//	x=_Ordinal[t];
				m=_music[t];
		//		y=x%7;
		//		z=_tab[y];
			//	n=delay(z);
					n=2000;
				while(n--) 
				{
						Beep=~Beep;
						Delay10us(m);
					//	n--;
				}  
		}
	}
}


void Delay10us(uint s)		//@11.0592MHz 0.01ms
{
	unsigned char i;

	i = 2*s;
	while (--i);
}
int delay(unsigned char t)

				{

				unsigned int i;

				unsigned char j=80;

				for(i=0; i<t; i++)//

				while(j--);

				
				}
