#include<reg52.h>
#define uchar unsigned char
#define uint unsigned int
#define ulong unsigned long
/*
	255的二进制形式1111 1111  上八位TH0  下八位TL0（最高能存255）
	各种情况下的16位定时器计时时间 t=12/晶振频率😂😂😂😂😂👀👀✨✨🤦‍♂️🤞🤳 
		同时 1 机械周期（单片机完成一次完整行为时间）== 12 时钟周期
			例如  晶振频率为12 MZH   t=12/(12000000) = 1 us
				  晶振频率为11.0592 MZH  t=12/(11059200) ~=1.09 us
		若要计算定时器设置次数 如 T=50 ms	(晶振频率为11.0592 MZH)
								N=50,000/1.09~=45872
*/