#include <reg52.h> 
#include <function.h>//??????8?
#define uchar unsigned char
#define uint unsigned int
sbit  LED2=P1^2;
 
 
 
 void delay_ms(uint xms)	//xms
{
  uint i,j;
  for(i = 0; i < xms; ++i)
    for(j = 0; j < 110; ++j);
}


void main()
{
		
    IT1= 0;   //????????
    EX1= 1;
    EA  = 1;
   LED2=1;
    
    while(1);
}
  
//??P3.3?P2.3????????
void EXTI1_IRQHandler() interrupt 2
{
    delay_ms(50);//???
    if(INT1==0)  //P3.3???????????????
    {		//delay_ms(50);
				if(INT1==1)
				{
					LED2=~LED2;
					
				}
    } 
}
