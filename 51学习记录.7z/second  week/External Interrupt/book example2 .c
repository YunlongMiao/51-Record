#include <reg52.h> 
#define uchar unsigned char
#define uint unsigned int
sbit  LED=P1^2;
 
void delay_ms(uint xms)	//xms
{
  uint i,j;
  for(i = 0; i < xms; ++i)
    for(j = 0; j < 110; ++j);
}


void main()
{  
    IT1 = 1;   //下降沿触发模式
    EX1 = 1;
    EA  = 1;
   
   
    while(1);
}
  

void EXTI1_IRQHandler() interrupt 2
{
    delay_ms(10);//去抖动
    if(INT1==0)  //P3.3是否还处于低电平的稳定接触状态
    {
        LED=!LED; 
    } 
}