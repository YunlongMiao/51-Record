  #include"reg52.h"
  #define uchar unsigned char
  #define uint unsigned int
  
  sbit pwm=P2^7;     
  sbit k1=P1^1;       
  sbit k2=P1^2;       
  
  uchar count=0;
 uchar n=5;       
 ��������������������
 void delay5ms()  
 {
     unsigned char a,b;
     for(b=19;b>0;b--)
         for(a=130;a>0;a--);
 }
 void key()����
 {
     if(k1==0)
     {
         delay5ms();
         if(k1==0)
            {
             while(k1==0); 
             if(n<=25)
             n++;������������
             else 
             n=26;           
            }
     }
     if(k2==0)
       {
         delay5ms();
         if(k2==0)
         {
             while(k2==0); 
             if(n>=6) n--; 
             else n=3;
         }
       }
 }
 
 void InitTimer()����
 {
     TMOD = 0x01;
     TH0 = 0xFF;
     TL0 = 0XA3;
     EA = 1;
     ET0 = 1;
     TR0 = 1;
 }
 
 void main()
 {
     InitTimer();
        while(1)
         {
           key();
         }
 }
 
 
 
 void Timer() interrupt 1 {����������������������������
     TH0 = 0xFF;
     TL0 = 0xA3;
     count++;
     if(count<=200)
     {
         if(count<=n)
         {
             pwm=1;
         }
        else
         {
             pwm=0;
         }
     }
     else
     {
         count=0;
         pwm=0;
     }
 }