#include<reg52.h>
#define uchar unsigned char
#define uint  unsigned int
sbit  led=P1^2;
uint temp=0,n=0,num=0,s=3000,l=10000;
void timer()
{
	TL0 = 0xE9;		//25us
	TH0 = 0xE9;
}
void main()
{
	TMOD=0x02;		
	TL0 = 0xE9;		//25us
	TH0 = 0xE9;
	EA = 1;
	ET0 = 1;
	TR0 = 1;
	while(1);
}

void T0_02timer() interrupt 1	//显示一个时间加的过程，
{								//慢慢亮起来的时候就让为0的时间慢慢边长
	timer();					//总时间相同200*5=1s
	if(1)
	{
		if(l<=200)
		{
			l=10000;
			s=3000;
			temp=!temp;
		}
		if(s>l)
		{
			led=0;
			s=0;
			l-=30;
		}
		else
		{
			led=1;
			s+=50;
		}
		
	}
	
}