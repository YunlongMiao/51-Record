#include<reg52.h>
#define uchar unsigned char
#define uint  unsigned int
sbit  LED=P1^2;
uint temp,n,num,s,l;
void timer()
{
	TH0=0x47;                          //定时器溢出值设置，每隔200us发起一次中断。
    TL0=0X47;
	s++;
	l++;
}
void main()
{
    l = 0;
    s = 0;
    num = 5;
    temp = 0;
    LED = 1;            //默认LED熄灭
	TMOD=0x02;		
	TL0 = 0xE9;		//25us
	TH0 = 0xE9;
	EA = 1;
	ET0 = 1;
	TR0 = 1;
    while(1);
}

void T0_02timer() interrupt 1	//显示一个时间加的过程，
{								//慢慢亮起来的时候就让为0的时间慢慢边长
	timer();					//总时间相同200*5=1s
	if(s == num)      //判断是否到了点亮LED的时候
        LED = 0;                    //点亮LED
    if(s == 10)                    //当前周期结束
    {
        LED = 1;                    //熄灭LED
        s = 0;                       //重新计时
    }
	 if((l == 600) && (temp == 0))         //占空比增加10%
    {                               
        l = 0;
        num++;
        if(num == 9)          //占空比更改方向
            temp = 1; 
    }
    if((l == 600) && (temp == 1))        //占空比减少10%
    {                               
        l = 0;
        num--;
        if(num == 1)          //占空比更改方向
            temp = 0; 
    }   
}