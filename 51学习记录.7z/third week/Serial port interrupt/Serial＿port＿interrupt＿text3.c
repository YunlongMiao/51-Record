#include<reg51.h>
void UsartConfiguration();
void main()
{
	UsartConfiguration();
	while(1)
	{
		
	}
}
void UsartConfiguration() 
{
	SCON=0X50;
	TMOD=0X20;
	PCON=0X80;
	TH1=0XFd;
	TL1=0XFd;
	ES=1;
	EA=1;
	TR1=1;
}
void Usart() interrupt 4
{
	unsigned char receiveData;
	receiveData=SBUF;
	RI = 0;
	SBUF=receiveData;
	while(!TI);
	TI = 0;
}