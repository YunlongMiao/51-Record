#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char
uchar temp;
void definition()
{
	TMOD=0x20;
	SM0=0;
	SM1=1;
	TH1=0xa0;//9600
	TL1=0xa0;
	REN=1;
	EA=1;
	TR1=1;
	ES=1;
}
void main()
{
	uint  a;
	definition();
	while(1)
	{
		temp=1;		//接收状态
		if(temp==1)
		{
			ES=0;
			while(RI==0);
			a=SBUF;
			if(a==1)
			P1=0x00;
			RI=0;
			//temp=0;
			ES=1;
		}
		if(temp==0)
		{
			ES=0;
			while(TI==0);
			SBUF='I';
			TI=1;
			ES=1;
			
		}
	}
}
void T1_timer() interrupt 4
{
	TI=0;
	RI=0;
	temp=0;
}