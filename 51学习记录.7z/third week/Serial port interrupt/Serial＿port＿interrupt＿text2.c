#include<reg52.h>
#define uchar unsigned char
#define uint unsigned int
	uchar s,t,temp;
void main()
{
	TMOD=0x20;
	TH1=0xfd;
	TL1=0xfd;
	REN=1;
	SM0=0;
	SM1=1;
	TR1=1;
	EA=1;
	ES=1;
	temp=1;
	while(1)
	{
		if(temp==0)
		{
			ES=0;
			SBUF=s;
			while(!TI);
			TI=0;
			ES=1;
			temp=1;
		}
	}
}

void inter()interrupt 4
{
	if(temp==1)
	{
		ES=0;
		RI=0;
		s=SBUF;
		RI=0;
		temp=0;
		ES=1;
	}
}