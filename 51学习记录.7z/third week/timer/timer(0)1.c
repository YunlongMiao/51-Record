#include<reg51.h>
#define uchar unsigned char
#define uint unsigned int
sbit LED1=P1^2;
//sbit LED2=P1^1;
uint n=0;

void main()		
{
	TMOD=0x00;		
	TH0=144;//(8192-3584)/32;			
	TL0=0;//(8192-3584)%32;	//5ms
	EA=1;
	ET0=1;
	TR0=1;
	while(1)
	{
		if(n>=200)
		{
			LED1=~LED1;
			n=0;
		}
		
	}
}

void T0_timer()interrupt 1
{	
	TH0=144;//(8192-3584)/32;			
	TL0=0;//(8192-3584)%32;	
	n++;
}