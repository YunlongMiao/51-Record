#include<reg52.h>
#include <stdlib.h>
#include <intrins.h>
#include <stdio.h>
#define uint unsigned int 
#define uchar unsigned char
 
sbit PSB  = P2^0;
sbit CS   = P2^1;
sbit SID  = P2^2;
sbit SCLK = P2^3;


void LCD_SendByte(uchar Sdate);
void LCD12864_Command(uchar cmd);
void LCD12864_Wdat(uchar dat);
void init_lcd(void);
void LCD12864_SetPos(uchar x,uchar y);
void LCD12864_DisHZ_Str(uchar *s);



void Delay10us(uint us)
{
	while(us--);
}


void main()
{
	uchar sec=0;				
	CS = 1;
	LCD12864_Command(0x30);	//基本指令集
	LCD12864_Command(0x0C);	//D2,D1,D0: 1,0,0 显示开，光标关，闪烁关
	init_lcd();
	LCD12864_SetPos(0,0);
//	LCD12864_DisHZ_Str("数\xfd学");
//		LCD12864_DisHZ_Str("一er");
	LCD12864_DisHZ_Str("xb3xa4xb4");
	LCD12864_SetPos(1,0);
	LCD12864_DisHZ_Str("efghijklmnop");
	LCD12864_SetPos(2,0);
	LCD12864_DisHZ_Str("!,./?#$%^&*()");
	LCD12864_SetPos(3,0);
	LCD12864_DisHZ_Str("1234567890123");
	while(1);			
}



void init_lcd(void)		//清屏
{
	PSB = 0;							//串行为0，并行为1
	CS = 1;
	LCD12864_Command(0x30); 	/*30---基本指令动作*/
	LCD12864_Command(0x01); 	/*清屏，地址指针指向00H*/
	Delay10us(100);
	LCD12864_Command(0x06); 	/*光式的移动方向*/
	LCD12864_Command(0x0c);	 /*开显示，关游标*/
}




void LCD_SendByte(uchar Sdate)		//顺序发送8位数据	7->0
{
	uchar i;
	for(i=0; i<8; i++)
	{
		SCLK = 0;	
		SID = Sdate & 0x80;
		Sdate =  Sdate << 1;									//上升沿写入
		SCLK = 1;
	}
}

//每行数据的发送有三个步骤：1.连续写入11111  2. 8位数据前四位  3.8位数据后四位

void LCD12864_Command(uchar cmd)	//命令
{	
	
	LCD_SendByte(0xf8);					//命令模式0xf8
	LCD_SendByte(cmd & 0xf0);
	LCD_SendByte(cmd << 4);
	Delay10us(10);
	
}

//	0xf8  1111 1000
//	0xfa  1111 1010
//	0xf0  1111 0000

void LCD12864_Wdat(uchar dat)	//对每个文字进行发送
{
	
	LCD_SendByte(0xfa);					//数据模式0xfa
	LCD_SendByte(dat & 0xf0);
	LCD_SendByte(dat << 4);
	
}

void LCD12864_SetPos(uchar x,uchar y)
{
	uchar pos;
	switch(x)
	{
		case 0 : x = 0x80;break;
		case 1 : x = 0x90;break;
		case 2 : x = 0x88;break;
		case 3 : x = 0x98;break;
		default:break;
	}
	pos = x + y;										//x范围：0-3，y范围：0-7
	LCD12864_Command(pos);
	
}

void LCD12864_DisHZ_Str(uint *s)	//从首个内容开始，一直往下，直至读完为0时停止
{
//		uchar m;
			while(*s)
//			{
//				for(m=0; m<2; m++)
//				LCD12864_Wdat(*(s+m));
//			}
//			*s=*(s+m);
			LCD12864_Wdat(*s++);
			Delay10us(200);
}
