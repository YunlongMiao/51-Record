#include<reg52.h>
#include <stdlib.h>
#include <intrins.h>
#include <stdio.h>
typedef unsigned char u8;
#define uint unsigned int 
#define uchar unsigned char
//sbit RS = P1^1;
//sbit RW = P1^2;
//sbit E  = P1^3;
sbit PSB  = P2^4;
sbit CS   = P2^7;
sbit SID  = P2^6;
sbit SCLK = P2^5;
void LCD_SendByte(uchar Sdate);
void LCD12864_WCMD(uchar cmd);
void LCD12864_WDAT(uchar dat);
void LCD12864_SetPos(uchar x,uchar y);
void LCD12864_DisHZ_Str(uchar *s);
void Delay10us(uint us)
{
	while(us--);
}
void main()
{
	u8 sec=0;
//	uint sec=0;
	PSB = 0;				//串行为0，并行为1 
	CS = 1;
	LCD12864_WCMD(0x30);	//基本指令集     D4,D3 : 1,0   	 8位接口，基本指令
	LCD12864_WCMD(0x0C);	//开启显示功能   D2,D1,D0: 1,0,0 显示开，光标关，闪烁关
	LCD12864_SetPos(0,0);
	LCD12864_DisHZ_Str("Welcome to BGMCU");
	LCD12864_SetPos(1,0);
	LCD12864_DisHZ_Str("Welcome to BGMCU");
	LCD12864_SetPos(2,0);
	LCD12864_WDAT(0x1A);
	LCD12864_WDAT(' ');
	LCD12864_DisHZ_Str("12:13:20基本指令集");
	LCD12864_SetPos(3,0);
	LCD12864_WDAT(0x03);
	LCD12864_WDAT(' ');
	LCD12864_DisHZ_Str("Welcome to BGMCU");
	while(1)
	{
		Delay10us(50000);	//延时50000x10us=500ms
		Delay10us(50000);	//延时50000x10us=500ms
		if(sec<60)
			sec++;
		else
			sec = 0;
		LCD12864_SetPos(2,4);
		LCD12864_WDAT(sec/10 + '0');
		LCD12864_WDAT(sec%10 + '0');
	}
}
/*
void LCD12864_BusyCheck()
{
	unsigned char temp;
	P0 = 0xFF;
	RS = 0;
	RW = 1;
	while(1)
	{
		E = 1;
		temp = P0;
		E = 0;
		if((temp & 0x80) == 0)
			break;
	}
}
*/


void LCD_SendByte(uchar Sdate)		//顺序发送8位数据

{
	uchar i;
	for(i=0; i<8; i++)
	{
		SID = Sdate & 0x80;
		Sdate =  Sdate << 1;
		SCLK = 0;
		SCLK = 1;
	}
}

//每行数据的发送有三个步骤：1.连续写入11111  2. 8位数据前四位  3.8位数据后四位
void LCD12864_WCMD(uchar cmd)	//命令
{	
	LCD_SendByte(0xf8);			//命令模式0xf8
	LCD_SendByte(cmd & 0xf0);
	LCD_SendByte(cmd << 4);
	Delay10us(10);
}

//	0xf8  1111 1000
//	0xfa  1111 1010
//	0xf0  1111 0000

void LCD12864_WDAT(uchar dat)	//对每个文字进行发送
{
	LCD_SendByte(0xfa);			//数据模式0xfa
	LCD_SendByte(dat & 0xf0);
	LCD_SendByte(dat << 4);
}

void LCD12864_SetPos(uchar x,uchar y)
{
	unsigned char pos;
	switch(x)
	{
		case 0 : x = 0x80;break;
		case 1 : x = 0x90;break;
		case 2 : x = 0x88;break;
		case 3 : x = 0x98;break;
		default:break;
	}
	pos = x + y;	//x范围：0-3，y范围：0-7
	LCD12864_WCMD(pos);
}

void LCD12864_DisHZ_Str(uchar *s)	//从首个内容开始，一直往下，直至读完为0时停止
{
	while(*s)
		LCD12864_WDAT(*s++);
}