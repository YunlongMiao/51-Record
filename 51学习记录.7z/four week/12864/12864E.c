#include<reg52.h>
#include<intrins.h>
#define uint unsigned int
#define uchar unsigned char

		
sbit PSB = P2^0;
sbit CS  = P2^1;
sbit SID = P2^2;
sbit SCLK= P2^3;

