#include<reg51.h>
sbit D1_1=P1^2;
unsigned int a; 
void main()
{
	while(1)
	{
		a=50000;
		D1_1=1;
		while(a--);
		a=50000;
		D1_1=0;
		while(a--);
	}
}