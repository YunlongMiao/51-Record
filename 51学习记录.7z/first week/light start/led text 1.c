#include <reg51.h> 
#include<intrins.h>
#define uchar unsigned char
#define uint  unsigned int
sbit light=P1^2;//light
sbit set=P1^7;//anjianjiekou
uchar i,t;
void main()
{
	void delay(unsigned int s);
	set=1;
	light=0;
	
	while(1)
	{
		
		
			
			for(i=0;i<10;i++)
			{
					delay();
					if(set==0)
						i=0;
			
			}
			
			light=~light;
		
		
			
			for(i=0;i<10;i++)
			{
					delay();
					if(set==1)
						i=0;
			}

		
	}
}

//

void delayms(void)
{
	uchar a,b,c;
	for(c=1; c>0; c--)
		for(b=38; b>0; b--)
			for(a=13; a>0; a--);
}
