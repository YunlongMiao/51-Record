#include <reg51.h> 
#include<intrins.h>
#define uchar unsigned char
#define uint  unsigned int
sbit LED=P1^2;//light
sbit K1=P1^7;//anjianjiekou

void delay10ms(void)
{
	uchar a,b,c;
	for(c=1; c>0; c--)
		for(b=38; b>0; b--)
			for(a=130; a>0; a--);
}

void main (void)
{
	while(1)
	{
		delay10ms();
		if(K1==0)
		{
			LED=0;
		}
	}
}