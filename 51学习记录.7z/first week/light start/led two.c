#include<reg51.h>
#define uchar unsigned char
#define uint  unsigned int
sbit  LED=P1^0;
uint he[8]={0xfe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f};
uint i;

void delayms(unsigned int s)
{
	uchar a,b,c;
	for(c=1; c>0; c--)
		for(b=38; b>0; b--)
			for(a=13; a>0; a--)
				for(; s>0; s--);
}


void main()
{		EA  = 1;
		LED=1;
	 P1=0xff;
	
	 IT0 = 1;   
   EX0 = 1;
 //  EA  = 1;
	
	for(i=0; i<8; i++)
	{
		P1=he[i];
	   delayms(20000);
	}

	
}

void EXTI1_IRQHandler() interrupt 2
{
    delayms(10);
    if(INT1==0)
		{
			LED=0;
			delayms(800000);
		}	
			
}