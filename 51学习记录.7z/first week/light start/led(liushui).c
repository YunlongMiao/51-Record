#include<reg51.h>
#include<intrins.h>
sbit Ze_1=P1^0;
sbit Ze_2=P1^7;
unsigned char temp;
void delay(unsigned int s);
void main()
{
	temp=0xfe;
	P1=temp;
	while(1)
	{
		temp=_crol_(temp,1);
		delay();
		P1=temp;
		delay();
	}	
}
void delay(unsigned int s)
	{
		unsigned char i;
		while(s--)
		{
			for(i=18432;i>0; i--);
		}
	}
		