#include<reg51.h>
#define uchar unsigned char
#define uint  unsigned int
sbit light=P1^2;
sbit set=P1^7;
unsigned char temp;
void delayms(unsigned int s);
void main()
{
	uint key=0;

			key=1;		
				while(1)
				{
						
						if(set==0)
						{
							if(set==0)
							{
								while(!set);		//songkai

								key=0-key;
							}
							
						}
							if(key==1)
								{
									light=0;
									delayms(10);
								}
								else if(key==-1)
								{
									light=1;
									delayms(10);
								}
			}
	
	
}
void delayms(unsigned int s)
{
	uchar a,b,c;
	for(c=1; c>0; c--)
		for(b=38; b>0; b--)
			for(a=13; a>0; a--)
				for(; s>0; s--);
}

