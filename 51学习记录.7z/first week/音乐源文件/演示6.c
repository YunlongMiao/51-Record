

		

				#include<reg51.h>

				sbit speaker=P2^3;

				unsigned char duration;

				// 小星星句子，三个一组，第一个表示音符，第二个表示音阶，第三个表示延时长度(单位约等于0.1s)

				code unsigned char music[]={

				1,0.5,  1,0.5,  5,0.5,  5,0.5,  6,0.5,  6,0.5,  
				5,1,  4,0.5,  4,0.5,  3,0.5,  3,0.5,  2,1,  
				5,0.5,  5,0.5,  4,0.5,  4,0.5,  3,0.5,  3,0.5,  
				2,1,  1,0.5,  1,0.5,  5,0.5,  5,0.5,  6,0.5,  
				6,0.5,  5,1,  4,0.5,  4,0.5,  3,0.5,  3,0.5,  
				2,0.5,  2,0.5,  1,1};

				
				void song();

				void delay(unsigned char t);

				void main(void)

			{

				unsigned char index, step;

				

				while(1)

				{

					step=0;

					while(step<126)

					{

					index = music[step] + 7 * music[step+1] - 1;

					

					duration = music[step+2];   //节拍停留时间

					step += 3;
					
					
					song(index);

					}

				delay(10);

				}

			}

				

				void delay(unsigned char t)

				{

				unsigned int i;

				unsigned char j=80;

				for(i=0; i<t; i++)//

				while(j--);

				

				}

				void song(int q)

				{

				uint i;
				for(i=q;i>0;i--)

				speaker=0;
				delay(duration);
				speaker=1;
				delay(duration);

				}								