#include<reg51.h>
#define uchar unsigned char
#define uint unsigned int
sbit beep=P1^5;
uint music[]={437,390,347,328,292};
int play(int p)
{
		int j;
	for(j=p/2;j>0;j--);
		beep=0;
	for(j=p/2;j>0;j--);
		beep=1;
}
void main()
{
	int i;
	beep=1;
	while(1)
	{
		
		for(i=0;i<5;i++)
		{	 
			int n=200;
			while(n--)
			{			
				play(music[i]);
			}
		}			
	}
}