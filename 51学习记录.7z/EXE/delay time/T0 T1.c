单片机制作的时钟程序
作者：佚名    文章来源：本站原创    点击数：419    更新时间：2018-03-07
今天完成的一个用单片机制作的时钟程序，
/****************************************************************
*工程名：带秒显示时钟单片机程序                    *
*单片机：STC89C52 *
*电路板：http://www.dzkfw.com.cn/index.html  *
*目  的：学习单片机编程 *
*是 间：2018-01-25星期五 *
*修  订：功能有待完善，下边我还加上调整时间的功能 *
*****************************************************************/
#include
#define uint unsigned int
#define uchar unsigned char
sbit wei=P2^7;  //位锁存器使能端定义
sbit duan=P2^6;  //段锁存器使能端定义
sbit led=P1^4;  //这个是我买的实验板上的led使能端控制位
//定义需要的为变量...
uchar code duan_table[]={
0x3f,0x06,0x5b,0x4f,
0x66,0x6d,0x7d,0x07,
0x7f,0x6f,0x77,0x7c,
0x39,0x5e,0x79,0x71,0x00
};//数码管从1——F显示编码表，记得最后一个分号哦...
uchar a,xiaoshi,fenzhong,miao,miao1,miao2,xiao1,xiao2,fen1,fen2; //定义要用到的变量，记得一个字符都不要写错哦...
void dispay(uchar miao1,uchar miao2,uchar fen1,uchar fen2,uchar xiao1,uchar xiao2); //显示函数什么，一定要记得什么哦...
void delay(uchar x);
void init()//初始化函数
{
TMOD=0X01; //定时计数器工作模式，工作于16位定时器计数器模式
TH0=(65536-50000)/256;  //十六位寄存器高八位赋初值
TL0=(65536-50000)%256;  //............低八位赋初值
EA=1; //开总中断
ET0=1; //开定时器计数器0中断
TR0=1; //启动定时器/计数器0
}
void main()
{
init();   //调用初始化函数
while(1)
{
if(a==20) //判断是否定时到1秒钟
{
a=0; //到一秒a清零
miao++; //让秒加1
if(miao==60) //判断秒是否到60
{
miao=0; //秒到60，让"miao"清零
fenzhong++; //让分钟自加1
if(fenzhong==60) //判断分钟是否到60
{
fenzhong=0;  //分钟到60，让"fenzhong"清零
xiaoshi++;   //让小时加1
if(xiaoshi==24) //判断小时是否到24
{xiaoshi=0;}  //到24，让"xiaoshi"清零，从零点从新走动...
}
}
xiao1=xiaoshi/10;
xiao2=xiaoshi%10;  //上面一行和这一行是把小时的两位分离出来，比如23，分解成2和3；下面几行一样就不解释了
fen1=fenzhong/10;
fen2=fenzhong%10;
miao1=miao/10;
miao2=miao%10;
}
dispay(miao1,miao2,fen1,fen2,xiao1,xiao2);
}
}
void dispay(uchar miao1,uchar miao2,uchar fen1,uchar fen2,uchar xiao1,uchar xiao2)
{
duan=1;
P0=duan_table[xiao1];
duan=0;
P0=0xff;
wei=1;
P0=0xfb;//第三个LED亮，小时高位
wei=0;
delay(2);
duan=1;
P0=duan_table[xiao2];
duan=0;
P0=0xff;
wei=1;
P0=0xf7;  //第四个LED亮，小时低位
wei=0;
delay(2);
duan=1;
P0=duan_table[fen1];
duan=0;
P0=0xff;
wei=1;
P0=0xef; //第五个LED亮，分钟高位
wei=0;
delay(2);
duan=1;
P0=duan_table[fen2];
duan=0;
P0=0xff;
wei=1;
P0=0xdf;  //第六个LED亮，分钟低位
wei=0;
delay(2);
duan=1;
P0=duan_table[miao1];
duan=0;
P0=0xff;
wei=1;
P0=0xbf; //第七个LED亮，秒高位
wei=0;
delay(2);
duan=1;
P0=duan_table[miao2];
duan=0;
P0=0xff;
wei=1;
P0=0x7f;
wei=0;
delay(2);
}
void delay(uchar x)
{
uchar bb,dd;
for(bb=x;bb>0;bb--)
for(dd=110;dd>0;dd--);
}
void timer0() interrupt 1
{
TH0=(65536-50000)/256;
TL0=(65536-50000)%256;
a++;
}
