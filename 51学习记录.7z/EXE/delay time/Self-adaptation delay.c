//参数：ms，要延时的ms数，自动适应主时钟

#define MAIN_Fosc 11059200UL //定义主时钟HZ

typedef unsigned int INT16U;

void delay_ms(INT16U ms) //INT16U 等价于 unsigned int

{

INT16U i;

do{

i=MAIN_Fosc/9600;

while(--i); //96T per loop

}while(--ms); //--ms ms=ms-1

}

//5us 延时函数，自动适应主时钟

#define MAIN_Fosc 11059200UL //定义主时钟HZ

void delay5us()

{

#if MAIN_Fosc == 11059200

_nop_();

#elif MAIN_Fosc == 12000000

_nop_();

#elif MAIN_Fosc == 22118400

_nop_(); _nop_(); _nop_();

#elif

}

单片机中还可自动生成

//11.0592MHZ延时100微秒

void Delay100us() //@11.0592MHz

{

unsigned char i, j;

_nop_();

_nop_();

i = 2;

j = 15;

do

{

while (--j);

} while (--i);

}

//100US

void Delay100us() //@12.000MHz

{

unsigned char i, j;

i = 2;

j = 39;

do

{

while (--j);

} while (--i);

}

//100US

void Delay100us() //@24.000MHz

{

unsigned char i, j;

i = 3;

j = 82;

do

{

while (--j);

} while (--i);

}