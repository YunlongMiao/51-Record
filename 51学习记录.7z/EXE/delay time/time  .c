


No.1

void Delay10us(uint s)		// 0.01ms
{
	unsigned char i;

	i = 2*s;
	while (--i);
}


No.1.0

void Delay10us()  //10us
{
	unsigned char i;

	i = 2*s;
	
	while (--i);
}


void delayms(uint xms)
{
	uint i,j;
	for(i=xms; i>0; i--)
		for(j=110; j>0; j--);
}	


No.2


void delayms(uint xms)	//xms
{
  uint i,j;
  for(i = 0; i < xms; ++i)
    for(j = 0; j < 110; ++j);
}

No.2.0

void delay100ms()
{
  unsigned char a,b,c;
  for(c=19;c>0;c--)
    for(b=20;b>0;b--)
      for(a=130;a>0;a--);
}

