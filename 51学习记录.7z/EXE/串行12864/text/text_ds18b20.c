#include "text_main.h"
#include "text_delay.h"
#include "text_ds18b20.h"
#include "text_12864.h"


//ds18b20��ʼ��
uchar ds18b20int()         
{
        uchar i=0;
        DQ=0;
        i=70;
        while(i--);           //642us
        DQ=1;
        i=0;
        while(DQ)
        {
           Delayms(1);
           i++;
           if(i>5)
           {
              return 0;
           }
        }
        return 1;
				
}

void ds18b20write(uchar dat)//  д����
{
        uchar i,j;
        for(j=0;j<8;j++)
        {
                DQ=0;
                i++;
                DQ=dat&0x01;
//                i=6;
//                while(i--);        //68us
									_nop_();
									i = 28;
									while (--i);
                DQ=1;
                dat>>=1;
        }
							
}

uchar ds18b20read()          //������
{
         uint i,j;
        uchar cun,byte;
        for(j=8;j>0;j--)
        {
                DQ=0;
                i++;
                DQ=1;
                i++;
                i++;
                cun=DQ;
                byte=(byte>>1)|(cun<<7);
                i=4;
                while(i--);               
        }
        return byte;
}



//����ת��ָ��
void ds18b20chang()  
{
					ds18b20int();
          Delayms(1);				 
          ds18b20write(0xcc);        //����ROM
          ds18b20write(0x44);        //�����¶ȱ任�������¶ȵ�rom
}


//��ȡ����ת������¶�
void ds18b20readzhiling() 
{
          ds18b20int();
          Delayms(1);					 
          ds18b20write(0xcc);        
          ds18b20write(0xbe);			//���ݴ����ߵ�λ�¶�
}


//  ʵ���¶�ת��
int ds18b20readwendu()         
{
          int temp=0;
          uchar high,low;
          ds18b20chang();
          ds18b20readzhiling();
					low=ds18b20read();
          high=ds18b20read();         
					high = high << 8;
					temp =  high | low;
 //         temp=0xfc90;
//				temp=0x8;

					
           return temp;
}


void Config_Ds18b20(uchar resolution)//ds18b20��������
{
	ds18b20int();			//��λ
	ds18b20write(0xCC); // ����ROM
	ds18b20write(0x4e); // д�Ĵ���
	ds18b20write(0x7d0); // ������ֵ125
	ds18b20write(0x00); // ������ֵ0
	ds18b20write(resolution); //ds18b20��������
}
