#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char
uchar code table[] = "Hi";
uchar receiveFlag=0;				//标识位
	void init()
	{   
		TMOD = 0x20;	//设置定时器1为工作方式2；0010 0000  前四位，定时器1；后四位，定时器0
		
		TH1 = 0xA0;	    //T1 溢出率 = fosc /{12×[256 －（TH1）]}      8位自动重装
		TL1 = 0xA0;		//C51单片机串口通信方式1 波特率由定时器1的溢出率控制	9600
		
		SM0 = 0;		
		SM1 = 1;		//设定串行口工作方式 sm0,sm1 与m0，m1类似
		
		REN = 1;		//允许串行口接受位
		
		EA = 1;			//开总开关
		
		TR1 = 1;		//开启定时器1	

						// ES 串行中断允许位 	TI/RI：发送、接收中断标识位
	}
	
	void main()
	{
		uchar serVal,i;
		init();						//串口初始化
		receiveFlag = 1;
							   
		while(1)
		{
			if(receiveFlag == 1)		//接收开始
			{
				ES = 1;					//中断允许
				while(RI==0);			//RI接收中断标识位
					serVal = SBUF;		//serVal从串口缓存中读取
							           
					RI = 0;				//软件清零
					receiveFlag = 0;	//状态翻转
			}
			
			if(receiveFlag==0)			//发送开始
			{  			
				for(i =0;i<3;i++)
				{
					SBUF = table[i];	//发送内容预先储存在数组中
					while(TI==1);		//判断是否发送完毕。发送完成后，TI自动赋值1，需软件重新赋值0.
					TI = 0;				//软件赋值0
				}
				SBUF = serVal;			//串口缓存　储存发送数据
				while(TI ==0);
				TI = 0;
				receiveFlag = 1;
			}
		}
							 
	}
							
	void receive_data() interrupt 4
	{
		RI = 0;							//手动清0
		ES = 0;							// 接收完成后串行中断允许关闭。　　ES 串行中断允许位
		receiveFlag = 0;				
	}
