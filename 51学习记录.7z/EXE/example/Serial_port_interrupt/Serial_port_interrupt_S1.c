#include<reg52.h>
int a,leap=0;
void main()
{
  TMOD=0X20;
	TH1=0XA0;//波特率9600
	TL1=0XA0;
	TR1=1;//tcon寄存器定时器开关
	REN=1;
	SM0=0;//方式1
	SM1=1;
	EA=1;
	ES=1;//串行口中断允许位
	while(1)
	{
	if(leap==1)
	{
		ES=0;
	  leap=0;
	  SBUF=a;
	while(!TI);
	TI=0;
	ES=1;
	}
	}
}
void zhongduan() interrupt 4
{
  RI=0;
	a=SBUF;
	leap=1;
}