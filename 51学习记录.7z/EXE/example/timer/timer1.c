#include <reg52.h>                                              //52????????    p203
#define uchar unsigned char
#define uint unsigned int
sbit led1=P1^2;                   //  ???0  ????2??8??????????/???
uint num;
void main()
{
	TMOD=0x02;                                                  //?????0?????2(0000 0010)
	TH0=6;                                                           //???
	TL0=6;
	EA=1;                                                             //????
	ET0=1;                                                           //???? 0??
	TR0=1;                                                          //????? 0
	while(1)                                                         //?????????????
	{
		if(num==3686)                                      //????3686?,??1????
		{
			num=0;                                           //???num?0????3686?
			led1=~led1;                                    //????????
		}
	}
}
void T0_time() interrupt 1
{
	num++;
}