/*************************************************************/
/*                                                           */
/*  main.c文件代码                                            */
/*                                                           */
/*************************************************************/
#include"lcd12864.h"
#include"reg52.h"

#define uchar unsigned char
#define uint unsigned int

void delayms(unsigned int xms);
void lcd_init();
void writestring(unsigned char X,unsigned Y,unsigned char *p);
void testring(unsigned char *p);

char keyscan();                                       //定义独立按键函数
sbit key1=P2^0;                                       //声明单片机口P3口的第5位
sbit key2=P2^1;                                       //声明单片机口P3口的第4位
sbit key3=P2^2;                                       //声明单片机口P3口的第3位
sbit key4=P2^3;                                       //声明单片机口P3口的第2位
uchar a,key,b;
/*************************************************************/
/*                                                           */
/*  主函数，按键控制显示                                     */
/*                                                           */
/*************************************************************/
void main()
{   
    lcd_init();
    while(1)
    {   
        a=keyscan();
        if(a==1)
        {
            writestring(0,0,"202011205555");
        }
        a=keyscan();
        if(a==2)
        {
            writestring(1,0,"CSDN专业技术社区");
        }
        a=keyscan();
        if(a==3)
        {
            writestring(2,0,"12846液晶显示");
        }
        a=keyscan();
        if(a==4)
        {
            writestring(3,0,"串行通信");
        }
    }
}
/*************************************************************/
/*                                                           */
/*  独立按键控制                                             */
/*                                                           */
/*************************************************************/
char keyscan()                                       //定义独立按键函数，设计有返回值的函数更加方便，
{                                                   //注意有返回值函数的类型为返回值的类型
    if(key1==0)                                       //当key1按下时
    {                                               //软件防抖动     
        delayms(10);
        if(key1==0)
        {
            key=1;
            while(!key1);                           //等待按键释放/***若按键没有释放则key1始终为0,那么！key1始终为1。
        }        
    }
    if(key2==0)                                       //当key2按下时
    {
        delayms(10);                               //软件防抖动
        if(key2==0)
        {
            key=2;
            while(!key2);                           //等待按键释放/***若按键没有释放则key2始终为0,那么！key2始终为1。
        }
    }
    if(key3==0)                                       //当key3按下时
    {
        delayms(10);                               //软件防抖动
            if(key3==0)
            {
            key=3;
            while(!key3);                           //等待按键释放/***若按键没有释放则key3始终为0,那么！key3始终为1。
            }
    }
    if(key4==0)                                       //当key3按下时
    {
        delayms(10);                               //软件防抖动
            if(key4==0)
            {
            key=4;
            while(!key4);                           //等待按键释放/***若按键没有释放则key3始终为0,那么！key3始终为1。
            }
    }
    return key;
}
