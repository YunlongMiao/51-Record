/*************************************************************/
/*                                                           */
/*  lcd12864.h头文件代码                                            */
/*                                                           */
/*************************************************************/
#ifndef LCD12864_H
#define LCD12864_H
extern void delayms(unsigned int xms);			//延时
extern void lcd_write_cmd(unsigned char date);	//写命令
extern void lcd_write_data(unsigned char date);	//写数据
extern void lcd_sent_beyt(unsigned char date);	//发送一个字节
extern void lcd_pos(unsigned char X,unsigned Y);//坐标函数
extern void lcd_init();							//12864液晶初始化
extern void writestring(unsigned char X,unsigned Y,unsigned char *p);//中英文字符显示函数 
#endif
