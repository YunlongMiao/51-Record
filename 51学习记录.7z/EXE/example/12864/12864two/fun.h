#ifndef __FUN_H__
#define __FUN_H__

#include "ZhangType.h"
#include "String.h"                      //for strlen()
void Delay(uint16 time);              //??

#endif
