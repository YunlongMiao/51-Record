#include "fun.h"

void Delay(uint16 time)
{
    while(time--);
}
