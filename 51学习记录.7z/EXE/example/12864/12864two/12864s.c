
#include "12864s.h"

void SendByte(uint Byte)
{
        uint i;

        SCLK = 0;
        for(i = 0; i < 8; i++)
        {
                Byte <<= 1;
                SID = CY;
                SCLK = 1;
                SCLK = 0;               
        }
}

void Init12864s()
{
        Delay(500);
        Write12864s_Com(0x30);
        Delay(10);
        Write12864s_Com(0x0c);
        Delay(10);
        Write12864s_Com(0x01);
}

void Write12864s_Com(uint com)
{
        SendByte(WRCOM);
        SendByte(0xF0 & com);
        SendByte(com << 4);
}

void Write12864s_Dat(uint dat)
{
        SendByte(WRDAT);
        SendByte(0xF0 & dat);
        SendByte(dat << 4);
}