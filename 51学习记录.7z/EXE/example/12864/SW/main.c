#include<reg52.h>
sbit RS = P1^1;
sbit RW = P1^2;
sbit E  = P1^3;
void LCD12864_BusyCheck();
void LCD12864_WCMD(unsigned char cmd);
void LCD12864_WDAT(unsigned char dat);
void LCD12864_SetPos(unsigned char x,unsigned char y);
void LCD12864_DisHZ_Str(unsigned char *s);
void Delay10us(unsigned int us)
{
	while(us--);
}
void main()
{
	u8 sec=0;
	LCD12864_WCMD(0x0C);
	LCD12864_WCMD(0x30);
	LCD12864_SetPos(0,0);
	LCD12864_DisHZ_Str("Welcome to BGMCU");
	LCD12864_SetPos(1,0);
	LCD12864_DisHZ_Str("��絥Ƭ����ӭ��");
	LCD12864_SetPos(2,0);
	LCD12864_WDAT(0x1A);
	LCD12864_WDAT(' ');
	LCD12864_DisHZ_Str("12:13:20  ��һ");
	LCD12864_SetPos(3,0);
	LCD12864_WDAT(0x03);
	LCD12864_WDAT(' ');
	LCD12864_DisHZ_Str("2021��03�¡�");
	while(1)
	{
		Delay10us(50000);	//��ʱ50000x10us=500ms
		Delay10us(50000);	//��ʱ50000x10us=500ms
		if(sec<60)
			sec++;
		else
			sec = 0;
		LCD12864_SetPos(2,4);
		LCD12864_WDAT(sec/10 + '0');
		LCD12864_WDAT(sec%10 + '0');
	}
}

void LCD12864_BusyCheck()
{
	unsigned char temp;
	P0 = 0xFF;
	RS = 0;
	RW = 1;
	while(1)
	{
		E = 1;
		temp = P0;
		E = 0;
		if((temp & 0x80) == 0)
			break;
	}
}

void LCD12864_WCMD(unsigned char cmd)
{
	LCD12864_BusyCheck();
	RS = 0;
	RW = 0;
	P0 = cmd;
	E = 1;
	E = 0;
}

void LCD12864_WDAT(unsigned char dat)
{
	LCD12864_BusyCheck();
	RS = 1;
	RW = 0;
	P0 = dat;
	E = 1;
	E = 0;
}

void LCD12864_SetPos(unsigned char x,unsigned char y)
{
	unsigned char pos;
	switch(x)
	{
		case 0 : x = 0x80;break;
		case 1 : x = 0x90;break;
		case 2 : x = 0x88;break;
		case 3 : x = 0x98;break;
		default:break;
	}
	pos = x + y;	//x��Χ��0-3��y��Χ��0-7
	LCD12864_WCMD(pos);
}

void LCD12864_DisHZ_Str(unsigned char *s)
{
	while(*s)
		LCD12864_WDAT(*s++);
}