#include<reg51.h>
#define uchar unsigned char
#define uint unsigned int
sbit LED1=P1^2;
uint m=0,n=0,i,j;
void main()		
{
	TMOD=0x02;		
	TL0 = 0xE9;		//25us
	TH0 = 0xE9;
	EA=1;
	ET0=1;
	ET1=1;//1
	TR0=1;
	TR1=1;//1
	while(1)
	{
			for(i=0; i<40000; i+=1) 
			{
				if(n==i)
				{
					LED1=~LED1;
					n=0;
				}
			}
		
		
			for(j=40000; j>0 ; j-=1) 
			{
				if(m==j)
				{
					LED1=~LED1;
					m=0;
				}
			}
	}
}

void T0_timer()interrupt 1
{	
	TL0 = 0xE9;		//25us
	TH0 = 0xE9;
	n++;
}
void T1_timer()interrupt 3
{
	TL0 = 0xE9;		//25us
	TH0 = 0xE9;
	m++;
}