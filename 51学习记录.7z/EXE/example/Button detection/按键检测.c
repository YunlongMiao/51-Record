#include<reg51.h>
int a,k,j=0,l=1,c=1,i=0,s[6]={0x70,0xb0,0xd0,0xe0};
sbit key=P1^4;
char delay1()
{
	for(k=0;k<22000;k++)
		if(key==0)
		{
			for(a=0;a<500;a++);
				if(key==0)
				{
					if(i==3)
						j=0;
					else
						j=i+1;
					if(i==0)
						l=3;
					else
						l=i-1;
					while(key==0);
					return 1;
				}
		}
   return 0;
}
void main()
{ 
	while(1)
		if(c)
			for(i=j,j=0;i<4;i++)
			{
				P2=s[i];
				if(delay1())
				{
					c=!c;
					break;
				}
			}
		else
			for(i=l,l=3;i>=0;i--)
			{
				P2=s[i];
				if(delay1())
				{
					c=!c;
					break;
				}
				
			}
}